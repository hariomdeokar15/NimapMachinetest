package com.example.machinetest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MachineTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
