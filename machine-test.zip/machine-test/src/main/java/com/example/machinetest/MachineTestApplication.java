	package com.example.machinetest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MachineTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(MachineTestApplication.class, args);
		System.out.println("Project Started sucessfully!!");
	}

}
